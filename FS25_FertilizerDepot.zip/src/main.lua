-- =========================================================
-- FS25 Fertilizer Depot - Entry Point
-- =========================================================
-- Load order matters: constants first, then logger, then all
-- subsystems, then network events, then UI.

local modDir = g_currentModDirectory

-- Phase 1: Config
source(modDir .. "src/config/Constants.lua")
source(modDir .. "src/config/DepotSettings.lua")
source(modDir .. "src/DepotLogger.lua")

-- Phase 2: Core systems
source(modDir .. "src/integrations/SoilFertilizerBridge.lua")
source(modDir .. "src/DepotPricing.lua")
source(modDir .. "src/DepotSystem.lua")
source(modDir .. "src/DepotManager.lua")

-- Phase 3: Network
source(modDir .. "src/network/DepotPurchaseEvent.lua")
source(modDir .. "src/network/DepotSellEvent.lua")
source(modDir .. "src/network/DepotSiloFillEvent.lua")
source(modDir .. "src/network/DepotSyncEvent.lua")
source(modDir .. "src/network/DepotSettingsEvent.lua")

-- Phase 4: Placeables
source(modDir .. "src/placeable/PlaceableDepot.lua")
source(modDir .. "src/placeable/PlaceableSilo.lua")

-- Phase 5: UI (lazy-loaded on first open, but class must be defined)
source(modDir .. "src/ui/DepotDialog.lua")
source(modDir .. "src/ui/DepotSettingsDialog.lua")

-- ─── Mission00 Lifecycle Hooks ───────────────────────────

local function onMissionLoad(mission, ...)
    getfenv(0).g_DepotManager = DepotManager.new()
    g_DepotManager:initialize()
    DepotLogger.info("Mission load complete")
end

local function onMissionLoadFinished(mission, ...)
    if not g_DepotManager then return end
    -- SF global is now available if installed
    g_DepotManager.sfBridge:invalidateCache()
    DepotLogger.info("Post-load: SF installed: %s",
        tostring(g_DepotManager.sfBridge:isInstalled()))

    -- Register Shift+D settings hotkey in PLAYER context.
    -- Pattern mirrors FS25_SoilFertilizer:SoilFertilityManager.lua exactly.
    if PlayerInputComponent and PlayerInputComponent.registerActionEvents then
        local origRegister = PlayerInputComponent.registerActionEvents
        PlayerInputComponent.registerActionEvents = function(inputComp, ...)
            origRegister(inputComp, ...)

            -- Only register for the local (owning) player, not networked players
            if not (inputComp.player and inputComp.player.isOwner) then return end
            -- Guard against double-registration across level reloads
            if g_DepotManager and g_DepotManager._settingsEventId then return end
            if not g_DepotManager then return end

            if not InputAction.FD_OPEN_SETTINGS then
                DepotLogger.warning("InputAction.FD_OPEN_SETTINGS is nil — check modDesc <actions>")
                return
            end

            g_inputBinding:beginActionEventsModification(PlayerInputComponent.INPUT_CONTEXT_NAME)
            local ok, id = g_inputBinding:registerActionEvent(
                InputAction.FD_OPEN_SETTINGS, g_DepotManager,
                g_DepotManager.openSettingsDialog, false, true, false, true)
            if ok and id then
                g_DepotManager._settingsEventId = id
                g_inputBinding:setActionEventTextVisibility(id, false)
                DepotLogger.info("Shift+D (FD_OPEN_SETTINGS) registered in PLAYER context")
            else
                DepotLogger.warning("Shift+D registration failed — registerActionEvent returned false")
            end
            g_inputBinding:endActionEventsModification()
        end
    end
end

local function onMissionUpdate(mission, dt)
    if g_DepotManager then
        g_DepotManager:update(dt)
    end
end

local function onMissionDelete(mission, ...)
    if g_DepotManager then
        g_DepotManager:delete()
        getfenv(0).g_DepotManager = nil
    end
end

-- Save settings alongside savegame
local function onSaveToXML(missionInfo, xmlFile, ...)
    if not g_DepotManager then return end
    if not xmlFile then
        -- FSCareerMissionInfo.saveToXMLFile can fire before the XML handle is
        -- created (e.g. during onSaveStartComplete). Skip silently; the next
        -- real save call will carry a valid handle.
        DepotLogger.warning("onSaveToXML: xmlFile is nil — skipping settings save")
        return
    end
    g_DepotManager.settings:saveToXML(xmlFile, "fertilizerDepot.settings")
    DepotLogger.debug("Settings saved")
end

-- PREPEND so g_DepotManager exists before Mission00.load loads savegame placeables.
-- appendedFunction would create it AFTER onPostFinalizePlacement fires → depotId never set.
Mission00.load                        = Utils.prependedFunction(Mission00.load,                        onMissionLoad)
Mission00.loadMission00Finished       = Utils.appendedFunction(Mission00.loadMission00Finished,       onMissionLoadFinished)
FSBaseMission.update                  = Utils.appendedFunction(FSBaseMission.update,                  onMissionUpdate)
FSBaseMission.delete                  = Utils.appendedFunction(FSBaseMission.delete,                  onMissionDelete)
FSCareerMissionInfo.saveToXMLFile     = Utils.appendedFunction(FSCareerMissionInfo.saveToXMLFile,     onSaveToXML)

-- ─── Console Commands ────────────────────────────────────

addConsoleCommand("SoilDebugDepot", "Toggle FertDepot debug logging",
    "cmdDebugDepot", g_currentModName)

function cmdDebugDepot()
    DepotLogger._debug = not DepotLogger._debug
    print(DepotConstants.LOG_PREFIX .. " Debug: " .. tostring(DepotLogger._debug))
end
